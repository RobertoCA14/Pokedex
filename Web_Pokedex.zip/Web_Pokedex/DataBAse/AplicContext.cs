﻿using DataBAse.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace DataBAse
{
    public class AplicContext : DbContext
    {
        public AplicContext( DbContextOptions <AplicContext> options) : base(options) { }

        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region tables
            modelBuilder.Entity<Product>().ToTable("Products");
            modelBuilder.Entity<Category>().ToTable("Categories");
            #endregion

            #region"primary keys"
            modelBuilder.Entity<Product>().HasKey(h => h.Id);
            modelBuilder.Entity<Category>().HasKey(h => h.Id);
            #endregion

            #region"Relationships"
            modelBuilder.Entity<Category>()
                .HasMany<Product>(s => s.Products)
                .WithOne(g => g.Category)
                .HasForeignKey(s => s.CategoryId)
                .OnDelete(DeleteBehavior.Cascade);
            #endregion

            #region"Property configurations"

            #region products
            modelBuilder.Entity<Product>()
                .Property(p => p.Name)
                .IsRequired();

            modelBuilder.Entity<Product>()
               .Property(p => p.Price)
               .IsRequired();

            #endregion

            #region categories
            modelBuilder.Entity<Category>()
                .Property(p => p.Name)
                 .IsRequired()
                .HasMaxLength(100);
            #endregion

            #endregion
        }

    }
}
