﻿using Application.Repository;
using Application.ViewModel;
using DataBAse;
using DataBAse.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Services
{
    public class ProductService
    {
        private readonly ProductRepository _repository;

        public ProductService(AplicContext dbContext)
        {
            _repository = new(dbContext);
        }

        public async Task Add(SaveProductViewModel vm)
        {
            Product product = new();
            product.Name = vm.Name;
            product.Price = vm.Price;
            product.Url = vm.Url;
            product.Description = vm.Description;
            product.CategoryId = vm.CategoryId;

            await _repository.AddAsync(product);
        }

        public async Task Update(SaveProductViewModel vm)
        {
            Product product = new();
            product.Id = vm.Id;
            product.Name = vm.Name;
            product.Price = vm.Price;
            product.Url = vm.Url;
            product.Description = vm.Description;
            product.CategoryId = vm.CategoryId;

            await _repository.UpdateAsync(product);
        }

        public async Task Delete(int id)
        {
            var product = await _repository.GetByIdAsync(id);
            await _repository.DeleteAsync(product);
        }

        public async Task<SaveProductViewModel> GetByIdSaveViewModel(int id)
        {
            var product = await _repository.GetByIdAsync(id);
            SaveProductViewModel vm = new();
            vm.Id = product.Id;
            vm.Name = product.Name;
            vm.Description = product.Description;
            vm.CategoryId = product.CategoryId;
            vm.Price = product.Price;
            vm.Url = product.Url;

            return vm;
        }

        public async Task<List<ProductViewModel>> GetAllViewModel()
        {
            var list = await _repository.GetAllAsync();
            return list.Select(s => new ProductViewModel
            {
                Name = s.Name,
                Description = s.Description,
                Id = s.Id,
                Price = s.Price,
                Url = s.Url
            }).ToList();
        }
    
     }
}
