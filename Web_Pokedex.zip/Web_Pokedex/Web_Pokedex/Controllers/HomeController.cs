﻿using DataBAse;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Web_Pokedex.Models;
using Application.Services;

namespace Web_Pokedex.Controllers
{
    public class HomeController : Controller
    {
        private readonly ProductService _productService;
        public HomeController(AplicContext dbcontext)
        {
            _productService = new(dbcontext);
        }

        public async Task<IActionResult> Index()
        {
            var list = await _productService.GetAllViewModel();
            return View(list);
        }

        
    }
}